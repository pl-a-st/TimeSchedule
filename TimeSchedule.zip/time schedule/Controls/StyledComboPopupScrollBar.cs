﻿using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace time_schedule
{
    /// <summary>
    /// Применяет поддерживаемую Windows тему к штатному списку ComboBox.
    /// Не создаёт второго HWND и не вмешивается в захват мыши или прокрутку.
    /// Внешний вид системного скроллбара зависит от версии и настроек Windows.
    /// </summary>
    internal static class StyledComboPopupScrollBar
    {
        /// <summary>Данные Win32 о дочерних окнах ComboBox.</summary>
        [StructLayout(LayoutKind.Sequential)]
        private struct ComboBoxInfo
        {
            internal int Size;
            internal NativeRect Item;
            internal NativeRect Button;
            internal int ButtonState;
            internal IntPtr Combo;
            internal IntPtr Edit;
            internal IntPtr List;
        }

        /// <summary>Прямоугольник Win32, необходимый структуре COMBOBOXINFO.</summary>
        [StructLayout(LayoutKind.Sequential)]
        private struct NativeRect
        {
            internal int Left;
            internal int Top;
            internal int Right;
            internal int Bottom;
        }

        /// <summary>
        /// Оформляет уже существующий HWND списка. Не заменяет управление мышью,
        /// клавиатуру, подписки на события и сам список.
        /// </summary>
        /// <param name="combo">Исходный раскрывающийся список WinForms.</param>
        internal static void ApplyNativeTheme(ComboBox combo)
        {
            if (combo == null || combo.IsDisposed || !combo.IsHandleCreated) return;
            var info = new ComboBoxInfo { Size = Marshal.SizeOf(typeof(ComboBoxInfo)) };
            if (!GetComboBoxInfo(combo.Handle, ref info) || info.List == IntPtr.Zero)
            {
                Trace.TraceInformation("TS-04: HWND раскрытого списка ComboBox недоступен: " + combo.Name);
                return;
            }

            string requestedTheme = ThemeManager.Current == ThemeKind.Dark
                ? "DarkMode_Explorer" : "Explorer";
            int result = SetWindowTheme(info.List, requestedTheme, null);
            if (result < 0)
            {
                Trace.TraceInformation("TS-04: Windows не поддерживает тему списка " +
                    requestedTheme + " (HRESULT=0x" + result.ToString("X8") + ").");
            }
        }

        /// <summary>Возвращает дескриптор стандартного раскрытого списка.</summary>
        [DllImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetComboBoxInfo(IntPtr hwnd, ref ComboBoxInfo info);

        /// <summary>Выбирает системный вариант темы без собственных окон и перерисовки.</summary>
        [DllImport("uxtheme.dll", CharSet = CharSet.Unicode)]
        private static extern int SetWindowTheme(IntPtr hwnd, string appName, string idList);
    }
}
